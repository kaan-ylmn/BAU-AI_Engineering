#include "Shape.h"

Shape::Shape(int x_cord, int y_cord)
    : x_cord{x_cord}, y_cord{y_cord}{}
