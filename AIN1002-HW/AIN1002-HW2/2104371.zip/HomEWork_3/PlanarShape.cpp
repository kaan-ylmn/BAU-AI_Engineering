#include "PlanarShape.h"

PlanarShape::PlanarShape(int x_cord, int y_cord)
    :Shape(x_cord,y_cord) {}

double PlanarShape::area() {}


